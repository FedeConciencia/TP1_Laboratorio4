
package Controlador;

import Conexion.Conexion;
import Modelo.Noticia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import java.time.LocalDate;



public class ControladorNoticia {
    
    

    public static void insertarNoticia(Noticia noticia) {

        Connection conexion = null;
        Conexion con = new Conexion();
        PreparedStatement ps = null;  //Este objeto permite guardar las consultas que hacemos a la BD.
        ResultSet rs = null;  // este objeto lo usamos cuando obtenemos algo de la base de datos.

        try {

            conexion = con.getConnection(); //metodo getConnection, logueamos el usuario.

            ps = conexion.prepareStatement("INSERT INTO noticia (tituloNoticia, resumenNoticia, imagenNoticia, contenidoHtml, publicada, fechaPublicacion, idEmpresa) VALUES (?,?,?,?,?,?,?)");
            
            ps.setString(1, noticia.getTituloNoticia());
            ps.setString(2, noticia.getResumenNoticia());
            ps.setString(3, noticia.getImagenNoticia());
            ps.setString(4, noticia.getContenidoHtml());
            ps.setString(5, String.valueOf(noticia.getPublicada()));
            ps.setDate(6, Date.valueOf(noticia.getFechaPublicacion())); //Casteamos un LocalDate a sql.Date
            ps.setInt(7, noticia.getIdEmpresa());
            
          
            //Ejecutamos el comando y mandamos los datos al sistema:
            int resultado = ps.executeUpdate();

            if (resultado > 0) {
                
                System.out.println("El Registro fue insertado con exito a la Base de Datos.");
                //JOptionPane.showMessageDialog(null, "El Registro fue insertado con exito a la Base de Datos.");
                //out.print("<script>alert('El Registro fue insertado con exito a la Base de Datos.');<script>");

            } else {
                
                System.out.println("Error al intentar insertar el registro.");
                //JOptionPane.showMessageDialog(null, "Error al intentar insertar el registro.");
                //out.print("<script>alert('Error al intentar insertar el registro.');<script>");

            }

            conexion.close(); //cerramos la conexion.

        } catch (Exception ex) {

            System.err.println("Error. " + ex);
            //out.print("<script>alert('Error de Conexion.');<script>");
        } finally {

            try {
                ps.close();

            } catch (SQLException ex) {

                System.err.println("Error. " + ex);
                //out.print("<script>alert('Error de Conexion.');<script>");
            }

        }
    }

    public static void actualizarNoticia(String tituloNoticia, String resumenNoticia, String imagenNoticia, String contenidoHtml, char publicada, LocalDate fechaPublicacion, int idEmpresa, int id) {

        Connection conexion = null;
        Conexion con = new Conexion();
        PreparedStatement ps = null;  //Este objeto permite guardar las consultas que hacemos a la BD.
        ResultSet rs = null;  // este objeto lo usamos cuando obtenemos algo de la base de datos.

        try {

            conexion = con.getConnection(); //metodo getConnection, logueamos el usuario.

            ps = conexion.prepareStatement("UPDATE noticia SET tituloNoticia = ?, resumenNoticia = ?, imagenNoticia = ?, contenidoHtml = ?, publicada = ?, fechaPublicacion = ?, idEmpresa = ?  WHERE idNoticia = ? ");

            ps.setString(1, tituloNoticia);
            ps.setString(2, resumenNoticia);
            ps.setString(3, imagenNoticia);
            ps.setString(4, contenidoHtml);
            ps.setString(5, String.valueOf(publicada));  // casteamos el Char a String
            ps.setDate(6, Date.valueOf(fechaPublicacion)); //Casteamos un LocalDate a sql.Date
            ps.setInt(7, idEmpresa);
            ps.setInt(8, id);
           
            
            

            //Ejecutamos el comando y mandamos los datos al sistema:
            int resultado = ps.executeUpdate();

            if (resultado > 0) {

                 System.out.println("El Registro fue actualizado con exito a la Base de Datos.");
                //JOptionPane.showMessageDialog(null, "El Registro fue modificado con exito a la Base de Datos.");

            } else {
                
                System.out.println("Error al intentar actualizar el registro.");
                //JOptionPane.showMessageDialog(null, "Error al intentar modificar el registro.");

            }

            conexion.close(); //cerramos la conexion.

        } catch (Exception ex) {

            System.err.println("Error. " + ex);

        } finally {

            try {
                ps.close();

            } catch (SQLException ex) {
                
                System.err.println("Error. " + ex);
            }

        }

    }

    public static void eliminarNoticia(int id) {

        Connection conexion = null;
        Conexion con = new Conexion();
        PreparedStatement ps = null;  //Este objeto permite guardar las consultas que hacemos a la BD.
        ResultSet rs = null;  // este objeto lo usamos cuando obtenemos algo de la base de datos.

        try {

            conexion = con.getConnection(); //metodo getConnection, logueamos el usuario.

            ps = conexion.prepareStatement("DELETE FROM noticia WHERE idNoticia = ?");

            ps.setInt(1, id); //Se puede usar indicando el primer signo de pregunta del qwery y alojar la variable

            //Ejecutamos el comando y mandamos los datos al sistema:
            int resultado = ps.executeUpdate();

            if (resultado > 0) {

                  System.out.println("El Registro fue eliminado con exito a la Base de Datos.");
                //JOptionPane.showMessageDialog(null, "El Registro fue eliminado con exito a la Base de Datos.");

            } else {
                
                System.out.println("Error al intentar eliminar el registro.");
                //JOptionPane.showMessageDialog(null, "Error al intentar eliminar el registro.");

            }

            conexion.close(); //cerramos la conexion.

        } catch (Exception ex) {

            System.err.println("Error. " + ex);

        } finally {

            try {
                ps.close();

            } catch (SQLException ex) {
                System.err.println("Error. " + ex);
            }

        }

    }

    public static Noticia buscarOneNoticia(int id) {

        Connection conexion = null;
        Conexion con = new Conexion();
        Noticia noticia = null;
        PreparedStatement ps = null;  //Este objeto permite guardar las consultas que hacemos a la BD.
        ResultSet rs = null;  // este objeto lo usamos cuando obtenemos algo de la base de datos.

        try {

            conexion = con.getConnection(); //metodo getConnection, logueamos el usuario.

            ps = conexion.prepareStatement("SELECT idNoticia, tituloNoticia, resumenNoticia, imagenNoticia, contenidoHtml, publicada, fechaPublicacion, idEmpresa FROM noticia WHERE idNoticia = ?");

            ps.setInt(1, id); //pasamos el id parametro y se ingresa en el ? del query

            rs = ps.executeQuery();  //Ejecutamos el Resulset y executeQuery cuando obtenemos algo de la base de datos.

            if (rs.next()) {  //si nos devuelve un dato true

                int idNoticia = rs.getInt(1); //cada numero del parametro hace referencia al dato del campo que se desea obtener = idPersona
                String tituloNoticia = rs.getString(2);
                String resumenNoticia = rs.getString(3);
                String imagenNoticia = rs.getString(4);
                String contenidoHtml = rs.getString(5);
                char publicada = (rs.getString(6)).charAt(0);  //Casteamos el String BD a Char
                LocalDate fechaPublicacion = (rs.getDate(7)).toLocalDate();   //Casteamos sql.Date a util.Date
                int idEmpresa = rs.getInt(8);
                

                noticia = new Noticia(idNoticia, tituloNoticia, resumenNoticia, imagenNoticia, contenidoHtml, publicada, fechaPublicacion, idEmpresa); //Creamos el objeto con los datos Obtenidos

                System.out.println("El Registro fue encontrado con exito.");
                //JOptionPane.showMessageDialog(null, "El Registro fue encontrado con exito.");

            } else {

                System.out.println("El Registro no fue encontrado en la Base de Datos.");
                //JOptionPane.showMessageDialog(null, "El Registro no fue encontrado en la Base de Datos.");
            }

            conexion.close();

        } catch (Exception ex) {

            System.err.println("Error. " + ex);

        } finally {

            try {

                ps.close();
                rs.close();

            } catch (SQLException ex) {
                System.err.println("Error. " + ex);
            }

        }

        return noticia; //devolvemos el alumno encontrado
    }

    public static List<Noticia> buscarAllNoticia() {

        Connection conexion = null;
        Conexion con = new Conexion();
        Noticia noticia = null;
        List<Noticia> listaNoticia = new ArrayList<Noticia>();
        PreparedStatement ps = null;  //Este objeto permite guardar las consultas que hacemos a la BD.
        ResultSet rs = null;  // este objeto lo usamos cuando obtenemos algo de la base de datos.

        try {

            conexion = con.getConnection(); //metodo getConnection, logueamos el usuario.

            ps = conexion.prepareStatement("SELECT idNoticia, tituloNoticia, resumenNoticia, imagenNoticia, contenidoHtml, publicada, fechaPublicacion, idEmpresa FROM noticia");

            rs = ps.executeQuery();

            while (rs.next()) {

                int idNoticia = rs.getInt(1); //cada numero del parametro hace referencia al dato del campo que se desea obtener = idPersona
                String tituloNoticia = rs.getString(2);
                String resumenNoticia = rs.getString(3);
                String imagenNoticia = rs.getString(4);
                String contenidoHtml = rs.getString(5);
                char publicada = (rs.getString(6)).charAt(0); //Casteamos el String BD a Char
                LocalDate fechaPublicacion = (rs.getDate(7)).toLocalDate(); 
                int idEmpresa = rs.getInt(8);
                

                noticia = new Noticia(idNoticia, tituloNoticia, resumenNoticia, imagenNoticia, contenidoHtml, publicada, fechaPublicacion, idEmpresa); //Creamos el objeto con los datos Obtenidos

                listaNoticia.add(noticia);

            }

            conexion.close();

        } catch (Exception ex) {

            System.err.println("Error. " + ex);

        } finally {

            try {

                ps.close();
                rs.close();

            } catch (SQLException ex) {
                System.err.println("Error. " + ex);
            }

        }

        return listaNoticia; //devolvemos la lista de alumnos encontrado

    }
    
    
    
}
    
    
    

